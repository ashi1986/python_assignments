# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

#import tkinter
from tkinter import *
from tkinter import filedialog
import os
from PyPDF2 import PdfFileMerger
import logging

def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('PyCharm')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
logging.basicConfig(filename = "test.log", level = logging.INFO, format = '%(asctime)s %(levelname)s %(message)s')

frame = Tk()
frame.title("TextBox Input")
frame.geometry('800x400')

def listandmerge(filepath):
    logging.info("inside the function listandmerge")
    ispdfexists = False
    isResultFile = False
    try:
        files_list = os.listdir(filepath)
        merger = PdfFileMerger()
        for file in files_list:
            if file.endswith(".pdf"):
                if file == "Result.pdf":
                    os.remove(filepath + "\\" + file)
                    isResultFile = True
                else:
                    merger.append(filepath + "\\" + file)
                ispdfexists = True
            if not isResultFile:
                listbox.insert('end', file)
            else:
                isResultFile = False
        if ispdfexists:
            listbox.insert('end', "Result.pdf")
            merger.write(filepath + "\\" + "Result.pdf")
            lbl_list.config(text="PDF file exists, merge file: Result.pdf")
            logging.info("PDF file exists, merge file: Result.pdf")
        else:
            lbl_list.config(text="PDF file does not exists")
            logging.info("PDF file does not exists")
        merger.close()
    except Exception as e:
        logging.error("listandmerge::Error occurred", e)

def browse_dir():
    try:
        logging.info("Inside the function browse_dir")
        filepath = filedialog.askdirectory()
        lbl.config(text = "Input Directory: " + filepath)
        logging.info("Input Directory" + filepath)
        #list files
        listandmerge(filepath)
    except Exception as e:
        logging.error("browse_dir::Error occurred", e)
    finally:
        logging.shutdown()

# Button Creation
browseButton = Button(frame,
                        text = "Browse Directory",
                        command = browse_dir)
browseButton.pack()

#list box creation
listbox = Listbox(frame)
listbox.pack()

# Label Creation
lbl = Label(frame, text = "")
lbl.pack()

lbl_list = Label(frame, text = "")
lbl_list.pack()

frame.mainloop()

